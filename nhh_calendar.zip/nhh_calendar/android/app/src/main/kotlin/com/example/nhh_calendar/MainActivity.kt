package com.example.nhh_calendar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
