import 'package:flutter/material.dart';
import 'package:nhh_calendar/Providers/providers.dart';
import 'package:nhh_calendar/Pages/Home/home.dart';

void main() => runApp(
  MultiProvider(
    providers: [
      ChangeNotifierProvider(builder: (_) => Events()),
      ChangeNotifierProvider(builder: (_) => Setting())
    ],
    child: MyApp(),
  ),
);

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'NHH Calendar',
      theme: Provider.of<Setting>(context).themeData,
      darkTheme: Provider.of<Setting>(context).themes['dark'],
      home: HomePage(Provider.of<Events>(context).events),
    );
  }
}
